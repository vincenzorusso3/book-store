# BookStore

Java Servlet/JSP application using MVC, Tomcat 9 and a MySQL-compatible database.

## Avvio con Docker

Prerequisiti: Docker Engine (o Docker Desktop) e Docker Compose v2.
Dalla directory principale del repository:

```sh
cp .env.example .env
# Modifica DB_PASSWORD e DB_ROOT_PASSWORD in .env scegliendo password diverse.
docker compose up --build -d
```

Apri http://localhost:8080/BookStore/newhome.jsp.
La pagina di login è http://localhost:8080/BookStore/newlogin.jsp;
`/BookStore/` usa il welcome-file originale e reindirizza al login.
Il dump originale include gli account demo `admin` / `admin` e `mrossi1` / `mario`.

La build ricompila i sorgenti Java e genera un nuovo WAR: non usa il WAR
né le classi Eclipse precompilate presenti nel repository. Non occorre
installare Java, Maven o Tomcat sulla macchina host.

## Container e configurazione

- `app`: Tomcat 9 con JDK 17, eseguito da un utente non root.
- `db`: MariaDB 10.11, compatibile con i dump MySQL e il driver JDBC incluso.
- `DB_PASSWORD`: password dell'utente database `bookstore`, condivisa dai servizi.
- `DB_ROOT_PASSWORD`: password dell'amministratore del database.
- `APP_PORT`: porta locale dell'applicazione (default `8080`).

Il database è raggiungibile dall'app tramite `db:3306` e non pubblica porte
sull'host. L'app è esposta solo su `127.0.0.1`. Per eseguirla senza Compose,
configura `DB_HOST`, `DB_PORT`, `DB_USER` e `DB_PASSWORD` sul container.
Lo schema si chiama `book_store`: alcune query del progetto lo specificano
esplicitamente.

Al primo avvio vengono importati, nell'ordine, utenti, libri e carrello.
I dati restano nel volume `db_data` anche dopo `docker compose down`.
Gli script SQL vengono eseguiti **solo quando il volume è vuoto**.
Cambiare le password in `.env` non modifica gli utenti di un database già
inizializzato: aggiorna anche le credenziali nel database, oppure ricrea
il volume se i dati sono sacrificabili.

```sh
docker compose ps
docker compose logs -f app db
docker compose down
```

Dopo modifiche ai sorgenti:

```sh
docker compose up --build -d
```

Per ripartire dai dump originali, **cancellando tutti i dati del database**:

```sh
docker compose down -v
docker compose up --build -d
```

Questa configurazione è per sviluppo locale. L'app originale salva password
in chiaro e le inserisce nei cookie: prima di pubblicarla occorre correggere
l'autenticazione e sostituire gli account demo.
